using System;

namespace XamarinStore
{
	public class OrderResult
	{
		public bool Success { get; set; }
		public string OrderNumber { get; set; }
		public string Message { get; set; }
	}
}

