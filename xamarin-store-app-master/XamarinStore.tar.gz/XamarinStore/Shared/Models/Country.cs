﻿using System;

namespace XamarinStore
{
	public class Country
	{
		public string Code {get;set;}
		public string Name {get;set;}
	}
}

